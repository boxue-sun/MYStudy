cmake.. 完成后，需要将该目录下的文件替换到 build/src/asn-wrapper/asn_2(asn_3/asn_3_1)/asncodec
然后make