
#include "NvBufSurface.h"
#include "NvVideoDecoder.h"
#include "nvmpi.h"
#include <condition_variable>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
#include <unistd.h>
#include <vector>

// for debug
// #include <fstream>
// #include <string>
// std::ofstream out_log;

#define CHUNK_SIZE 4000000
#define MAX_BUFFERS 32

#define TEST_ERROR(cond, str, label)                                                                                   \
    if (cond) {                                                                                                        \
        cerr << str << " " << label << endl;                                                                           \
    }

using namespace std;

struct nvmpictx {
    NvVideoDecoder *dec{nullptr};
    bool eos{false};
    bool got_res_event{false};
    int index{0};
    unsigned int coded_width{0};
    unsigned int coded_height{0};
    int dst_dma_fd{0};
    int numberCaptureBuffers{0};
    int dmaBufferFileDescriptor[MAX_BUFFERS];
    nvPixFormat out_pixfmt;
    unsigned int decoder_pixfmt{0};
    std::thread *dec_capture_loop{nullptr};
    std::mutex *mutex{nullptr};
    std::condition_variable *has_frame_cv{nullptr};
    std::queue<int> *frame_pools{nullptr};
    unsigned char *bufptr_0[MAX_BUFFERS];
    unsigned char *bufptr_1[MAX_BUFFERS];
    unsigned char *bufptr_2[MAX_BUFFERS];
    unsigned int frame_size[4];
    unsigned int frame_linesize[4];
    unsigned long long timestamp[MAX_BUFFERS];
};

static void respondToResolutionEvent(v4l2_format &format, v4l2_crop &crop, nvmpictx *ctx) {
    NvVideoDecoder *dec = ctx->dec; // 解码器
    int32_t minimumDecoderCaptureBuffers;
    int ret = 0;
    NvBufSurfaceColorFormat pix_format;
    NvBufSurf::NvCommonAllocateParams params;
    NvBufSurf::NvCommonAllocateParams capParams;

    ret = ctx->dec->capture_plane.getFormat(format);
    TEST_ERROR(ret < 0, "Error: Could not get format from decoder capture plane", ret);

    ret = ctx->dec->capture_plane.getCrop(crop);
    TEST_ERROR(ret < 0, "Error: Could not get crop from decoder capture plane", ret);

    ctx->coded_width = crop.c.width;
    ctx->coded_height = crop.c.height;

    if (ctx->dst_dma_fd != -1) {
        ret = NvBufSurf::NvDestroy(ctx->dst_dma_fd);
        ctx->dst_dma_fd = -1;
        TEST_ERROR(ret < 0, "Error: Error in BufferDestroy", ret);
    }
    /* Create PitchLinear output buffer for transform. */
    params.memType = NVBUF_MEM_SURFACE_ARRAY;
    params.width = crop.c.width;
    params.height = crop.c.height;
    params.layout = NVBUF_LAYOUT_PITCH;
    if (ctx->out_pixfmt == NV_PIX_NV12) {
        params.colorFormat = NVBUF_COLOR_FORMAT_NV12;
    } else if (ctx->out_pixfmt == NV_PIX_YUV420) {
        params.colorFormat = NVBUF_COLOR_FORMAT_YUV420;
    } else if (ctx->out_pixfmt == NV_PIX_BGRA) {
        params.colorFormat = NVBUF_COLOR_FORMAT_BGRA;
    }

    params.memtag = NvBufSurfaceTag_VIDEO_CONVERT;
    ret = NvBufSurf::NvAllocate(&params, 1, &ctx->dst_dma_fd);
    TEST_ERROR(ret == -1, "create dmabuf failed", ret);

    /* deinitPlane unmaps the buffers and calls REQBUFS with count 0 */
    ctx->dec->capture_plane.deinitPlane();
    for (int index = 0; index < ctx->numberCaptureBuffers; index++) {
        if (ctx->dmaBufferFileDescriptor[index] != 0) {
            ret = NvBufSurf::NvDestroy(ctx->dmaBufferFileDescriptor[index]);
            TEST_ERROR(ret < 0, "Error: Error in BufferDestroy", ret);
        }
    }
    /* Not necessary to call VIDIOC_S_FMT on decoder capture plane.
   But decoder setCapturePlaneFormat function updates the class variables */
    ret = ctx->dec->setCapturePlaneFormat(format.fmt.pix_mp.pixelformat, format.fmt.pix_mp.width,
                                          format.fmt.pix_mp.height);
    TEST_ERROR(ret < 0, "Error in setting decoder capture plane format", ret);

    ctx->dec->getMinimumCapturePlaneBuffers(minimumDecoderCaptureBuffers);
    TEST_ERROR(ret < 0, "Error while getting value of minimum capture plane buffers", ret);

    ctx->numberCaptureBuffers = minimumDecoderCaptureBuffers + 5;

    switch (format.fmt.pix_mp.colorspace) {
    case V4L2_COLORSPACE_SMPTE170M:
        if (format.fmt.pix_mp.quantization == V4L2_QUANTIZATION_DEFAULT) {
            // "Decoder colorspace ITU-R BT.601 with standard range luma (16-235)"
            capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12;
        } else {
            //"Decoder colorspace ITU-R BT.601 with extended range luma (0-255)";
            capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12_ER;
        }
        break;
    case V4L2_COLORSPACE_REC709:
        if (format.fmt.pix_mp.quantization == V4L2_QUANTIZATION_DEFAULT) {
            //"Decoder colorspace ITU-R BT.709 with standard range luma (16-235)";
            capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12_709;
        } else {
            //"Decoder colorspace ITU-R BT.709 with extended range luma (0-255)";
            capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12_709_ER;
        }
        break;
    case V4L2_COLORSPACE_BT2020: {
        //"Decoder colorspace ITU-R BT.2020";
        capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12_2020;
    } break;
    default:
        if (format.fmt.pix_mp.quantization == V4L2_QUANTIZATION_DEFAULT) {
            //"Decoder colorspace ITU-R BT.601 with standard range luma (16-235)";
            capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12;
        } else {
            //"Decoder colorspace ITU-R BT.601 with extended range luma (0-255)";
            capParams.colorFormat = NVBUF_COLOR_FORMAT_NV12_ER;
        }
        break;
    }

    capParams.memType = NVBUF_MEM_SURFACE_ARRAY;
    capParams.width = crop.c.width;
    capParams.height = crop.c.height;
    capParams.layout = NVBUF_LAYOUT_BLOCK_LINEAR;
    capParams.memtag = NvBufSurfaceTag_VIDEO_DEC;

    ret = NvBufSurf::NvAllocate(&capParams, ctx->numberCaptureBuffers, ctx->dmaBufferFileDescriptor);
    TEST_ERROR(ret < 0, "Failed to create buffers", ret);

    /* Request buffers on decoder capture plane.
            Refer ioctl VIDIOC_REQBUFS */
    ret = dec->capture_plane.reqbufs(V4L2_MEMORY_DMABUF, ctx->numberCaptureBuffers);
    TEST_ERROR(ret, "Error in request buffers on capture plane", ret);

    /* Decoder capture plane STREAMON.
   Refer ioctl VIDIOC_STREAMON */
    ctx->dec->capture_plane.setStreamStatus(true);
    TEST_ERROR(ret < 0, "Error in decoder capture plane streamon", ret);

    /* Enqueue all the empty decoder capture plane buffers. */
    for (uint32_t i = 0; i < ctx->dec->capture_plane.getNumBuffers(); i++) {
        struct v4l2_buffer v4l2_buf;
        struct v4l2_plane planes[MAX_PLANES];

        memset(&v4l2_buf, 0, sizeof(v4l2_buf));
        memset(planes, 0, sizeof(planes));

        v4l2_buf.index = i;
        v4l2_buf.m.planes = planes;
        v4l2_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        v4l2_buf.memory = V4L2_MEMORY_DMABUF;
        v4l2_buf.m.planes[0].m.fd = ctx->dmaBufferFileDescriptor[i];

        ret = ctx->dec->capture_plane.qBuffer(v4l2_buf, NULL);
        TEST_ERROR(ret < 0, "Error Qing buffer at output plane", ret);
    }

    ctx->got_res_event = true;
    return;
}

static void *dec_capture_loop_fcn(void *arg) {
    nvmpictx *ctx = (nvmpictx *)arg;
    NvVideoDecoder *dec = ctx->dec;

    struct v4l2_format v4l2Format;
    struct v4l2_crop v4l2Crop;

    struct v4l2_event v4l2Event;

    int ret, buf_index = 0;
    while (!(dec->isInError() || ctx->eos)) {
        NvBuffer *dec_buffer;

        ret = dec->dqEvent(v4l2Event, ctx->got_res_event ? 0 : 500);
        if (ret == 0) {
            switch (v4l2Event.type) {
            case V4L2_EVENT_RESOLUTION_CHANGE:
                respondToResolutionEvent(v4l2Format, v4l2Crop, ctx);
                continue;
            }
        }

        if (!ctx->got_res_event) {
            continue;
        }

        while (!ctx->eos) {
            struct v4l2_buffer v4l2_buf;
            struct v4l2_plane planes[MAX_PLANES];
            v4l2_buf.m.planes = planes;

            if (dec->capture_plane.dqBuffer(v4l2_buf, &dec_buffer, NULL, 0)) {
                if (errno == EAGAIN) {
                    usleep(1000);
                } else {
                    ERROR_MSG("Error while calling dequeue at capture plane");
                    ctx->eos = true;
                }
                break;
            }

            /* Clip & Switch can be done by adjusting rectangle. */
            // NvBufSurf::NvCommonTransformParams transform_params;
            // transform_params.src_top = 0;
            // transform_params.src_left = 0;
            // transform_params.src_width = ctx->coded_width;
            // transform_params.src_height = ctx->coded_height;
            // transform_params.dst_top = 0;
            // transform_params.dst_left = 0;
            // transform_params.dst_width = ctx->coded_width;
            // transform_params.dst_height = ctx->coded_height;
            // transform_params.flag = NVBUFSURF_TRANSFORM_FILTER;
            // transform_params.flip = NvBufSurfTransform_None;
            // transform_params.filter = NvBufSurfTransformInter_Algo4; // NvBufSurfTransformInter_Default;

            ctx->mutex->lock();
            dec_buffer->planes[0].fd = ctx->dmaBufferFileDescriptor[v4l2_buf.index];

            if (!ctx->eos) {

                // ret = NvBufSurf::NvTransform(&transform_params, dec_buffer->planes[0].fd, ctx->dst_dma_fd);
                // out_log.open("nvmpi_l1.log", std::ofstream::app);
                // out_log << "NvTransform finished: " << ret << "\n";
                // out_log.flush();
                // out_log.close();
                // if (ret == -1) {
                //     ERROR_MSG("Transform failed");
                //     break;
                // }

                NvBufSurface *nvbuf_surf = nullptr;
                ret = NvBufSurfaceFromFd(dec_buffer->planes[0].fd, (void **)(&nvbuf_surf));
                // out_log.open("nvmpi_l1.log", std::ofstream::app);
                // out_log << "NvBufSurfaceFromFd finished: " << ret << "\n";
                // out_log << "numFilled : " << nvbuf_surf->numFilled << "\n";
                // for (uint32_t i = 0; i < nvbuf_surf->numFilled; i++) {
                //     out_log << " index : " << i << " nvbuf_surf->surfaceList[0].planeParams.num_planes:"
                //             << nvbuf_surf->surfaceList[i].planeParams.num_planes << "\n";
                //     out_log << " psize[0] : " << nvbuf_surf->surfaceList[i].planeParams.psize[0]
                //             << " psize[1] : " << nvbuf_surf->surfaceList[i].planeParams.psize[1]
                //             << " psize[2] : " << nvbuf_surf->surfaceList[i].planeParams.psize[2] << "\n";
                //     out_log << " width[0] : " << nvbuf_surf->surfaceList[i].planeParams.width[0]
                //             << " width[1] : " << nvbuf_surf->surfaceList[i].planeParams.width[1]
                //             << " width[2] : " << nvbuf_surf->surfaceList[i].planeParams.width[2] << "\n";
                //     out_log << " height[0] : " << nvbuf_surf->surfaceList[i].planeParams.height[0]
                //             << " height[1] : " << nvbuf_surf->surfaceList[i].planeParams.height[1]
                //             << " height[2] : " << nvbuf_surf->surfaceList[i].planeParams.height[2] << "\n";
                //     out_log << " bytesPerPix[0] : " << nvbuf_surf->surfaceList[i].planeParams.bytesPerPix[0]
                //             << " bytesPerPix[1] : " << nvbuf_surf->surfaceList[i].planeParams.bytesPerPix[1]
                //             << " bytesPerPix[2] : " << nvbuf_surf->surfaceList[i].planeParams.bytesPerPix[2] << "\n";
                // }
                // out_log.flush();
                // out_log.close();
                if (ret != 0) {
                    ERROR_MSG("NvBufSurfaceFromFd failed");
                    break;
                }
                auto &params = nvbuf_surf->surfaceList[0].planeParams;
                if (!ctx->frame_size[0]) {
                    for (int index = 0; index < MAX_BUFFERS; index++) {
                        ctx->bufptr_0[index] = new unsigned char[params.psize[0]];
                        if (params.num_planes == 2) { // means  ctx->out_pixfmt == NV_PIX_NV12) {
                            ctx->bufptr_1[index] = new unsigned char[params.psize[1]];
                        } else if (params.num_planes == 3) { // means ctx->out_pixfmt == NV_PIX_YUV420) {
                            ctx->bufptr_1[index] = new unsigned char[params.psize[1]];
                            ctx->bufptr_2[index] = new unsigned char[params.psize[2]];
                        }
                    }
                }

                ctx->frame_linesize[0] = params.width[0] * params.bytesPerPix[0];
                ctx->frame_size[0] = params.psize[0];
                NvBufSurface2Raw(nvbuf_surf, 0, 0, params.width[0], params.height[0], ctx->bufptr_0[buf_index]);
                if (params.num_planes == 2) { // means  ctx->out_pixfmt == NV_PIX_NV12) {
                    ctx->frame_linesize[1] = params.width[1] * params.bytesPerPix[1];
                    ctx->frame_size[1] = params.psize[1];
                    NvBufSurface2Raw(nvbuf_surf, 0, 1, params.width[1], params.height[1], ctx->bufptr_1[buf_index]);
                } else if (params.num_planes == 3) { // means ctx->out_pixfmt == NV_PIX_YUV420) {
                    ctx->frame_linesize[1] = params.width[1] * params.bytesPerPix[1];
                    ctx->frame_linesize[2] = params.width[2] * params.bytesPerPix[2];
                    ctx->frame_size[1] = params.psize[1];
                    ctx->frame_size[2] = params.psize[2];
                    NvBufSurface2Raw(nvbuf_surf, 0, 1, params.width[1], params.height[1], ctx->bufptr_1[buf_index]);
                    NvBufSurface2Raw(nvbuf_surf, 0, 2, params.width[2], params.height[2], ctx->bufptr_2[buf_index]);
                }

                ctx->frame_pools->push(buf_index);
                ctx->timestamp[buf_index] =
                    (v4l2_buf.timestamp.tv_usec % 1000000) + (v4l2_buf.timestamp.tv_sec * 1000000UL);

                buf_index = (buf_index + 1) % MAX_BUFFERS;
            }

            ctx->mutex->unlock();

            if (ctx->eos) {
                break;
            }

            ctx->has_frame_cv->notify_one();

            v4l2_buf.m.planes[0].m.fd = ctx->dmaBufferFileDescriptor[v4l2_buf.index];
            if (ctx->dec->capture_plane.qBuffer(v4l2_buf, NULL) < 0) {
                ERROR_MSG("Error while queueing buffer at decoder capture plane");
            }
        }
    }

    // Wake all waiting threads at EOS or decoder error
    ctx->has_frame_cv->notify_all();
    return nullptr;
}

nvmpictx *nvmpi_create_decoder(nvCodingType codingType, nvPixFormat pixFormat) {

    int ret;
    log_level = LOG_LEVEL_INFO;

    nvmpictx *ctx = new nvmpictx;

    ctx->dec = NvVideoDecoder::createVideoDecoder("dec0");
    TEST_ERROR(!ctx->dec, "Could not create decoder", ret);

    ret = ctx->dec->subscribeEvent(V4L2_EVENT_RESOLUTION_CHANGE, 0, 0);
    TEST_ERROR(ret < 0, "Could not subscribe to V4L2_EVENT_RESOLUTION_CHANGE", ret);

    switch (codingType) {
    case NV_VIDEO_CodingH264:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_H264;
        break;
    case NV_VIDEO_CodingHEVC:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_H265;
        break;
    case NV_VIDEO_CodingMPEG4:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_MPEG4;
        break;
    case NV_VIDEO_CodingMPEG2:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_MPEG2;
        break;
    case NV_VIDEO_CodingVP8:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_VP8;
        break;
    case NV_VIDEO_CodingVP9:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_VP9;
        break;
    default:
        ctx->decoder_pixfmt = V4L2_PIX_FMT_H264;
        break;
    }

    ret = ctx->dec->setOutputPlaneFormat(ctx->decoder_pixfmt, CHUNK_SIZE);
    TEST_ERROR(ret < 0, "Could not set output plane format", ret);

    // ctx->nalu_parse_buffer = new char[CHUNK_SIZE];
    ret = ctx->dec->setFrameInputMode(0);
    TEST_ERROR(ret < 0, "Error in decoder setFrameInputMode for NALU", ret);

    ret = ctx->dec->output_plane.setupPlane(V4L2_MEMORY_USERPTR, 10, false, true);
    TEST_ERROR(ret < 0, "Error while setting up output plane", ret);

    ret = ctx->dec->output_plane.setStreamStatus(true);
    TEST_ERROR(ret < 0, "Error in output plane stream on", ret);

    ctx->dec->disableDPB();
    ctx->dec->setMaxPerfMode(1);
    ctx->out_pixfmt = pixFormat;
    ctx->dst_dma_fd = -1;
    ctx->eos = false;
    ctx->got_res_event = false;
    ctx->index = 0;
    ctx->frame_size[0] = 0;
    ctx->frame_pools = new std::queue<int>;
    ctx->mutex = new std::mutex();
    ctx->has_frame_cv = new std::condition_variable();
    for (int index = 0; index < MAX_BUFFERS; index++)
        ctx->dmaBufferFileDescriptor[index] = 0;
    for (int index = 0; index < MAX_BUFFERS; index++) {
        ctx->bufptr_0[index] = nullptr;
        ctx->bufptr_1[index] = nullptr;
        ctx->bufptr_2[index] = nullptr;
    }
    ctx->numberCaptureBuffers = 0;
    ctx->dec_capture_loop = new thread(dec_capture_loop_fcn, ctx);

    return ctx;
}

int nvmpi_decoder_put_packet(nvmpictx *ctx, nvPacket *packet) {
    int ret;

    struct v4l2_buffer v4l2_buf;
    struct v4l2_plane planes[MAX_PLANES];
    NvBuffer *nvBuffer;

    memset(&v4l2_buf, 0, sizeof(v4l2_buf));
    memset(planes, 0, sizeof(planes));

    v4l2_buf.m.planes = planes;

    if (ctx->index < (int)ctx->dec->output_plane.getNumBuffers()) {
        nvBuffer = ctx->dec->output_plane.getNthBuffer(ctx->index);
    } else {
        ret = ctx->dec->output_plane.dqBuffer(v4l2_buf, &nvBuffer, NULL, -1);
        if (ret < 0) {
            std::cout << "Error DQing buffer at output plane" << endl;
            return -1;
        }
    }

    memcpy(nvBuffer->planes[0].data, packet->payload, packet->payload_size);
    nvBuffer->planes[0].bytesused = packet->payload_size;

    if (ctx->index < ctx->dec->output_plane.getNumBuffers()) {
        v4l2_buf.index = ctx->index;
        v4l2_buf.m.planes = planes;
    }

    v4l2_buf.m.planes[0].bytesused = nvBuffer->planes[0].bytesused;

    v4l2_buf.flags |= V4L2_BUF_FLAG_TIMESTAMP_COPY;
    v4l2_buf.timestamp.tv_sec = packet->pts / 1000000;
    v4l2_buf.timestamp.tv_usec = packet->pts % 1000000;

    ret = ctx->dec->output_plane.qBuffer(v4l2_buf, NULL);
    if (ret < 0) {
        std::cout << "Error Qing buffer at output plane" << std::endl;
        return -1;
    }

    if (ctx->index < ctx->dec->output_plane.getNumBuffers())
        ctx->index++;

    if (v4l2_buf.m.planes[0].bytesused == 0) {
        ctx->eos = true;
        std::cout << "Input file read complete" << std::endl;
    }

    return 0;
}

int nvmpi_decoder_get_frame(nvmpictx *ctx, nvFrame *frame, bool wait) {

    int ret, picture_index;
    std::unique_lock<std::mutex> lock(*ctx->mutex);

    if (wait) {
        while (ctx->frame_pools->empty() && !ctx->eos && !ctx->dec->isInError()) {
            ctx->has_frame_cv->wait(lock);
        }
    }

    if (ctx->frame_pools->empty()) {
        return -1;
    }

    picture_index = ctx->frame_pools->front();
    ctx->frame_pools->pop();

    frame->width = ctx->coded_width;
    frame->height = ctx->coded_height;

    frame->linesize[0] = ctx->frame_linesize[0];
    frame->linesize[1] = ctx->frame_linesize[1];
    frame->linesize[2] = ctx->frame_linesize[2];

    frame->payload[0] = ctx->bufptr_0[picture_index];
    frame->payload[1] = ctx->bufptr_1[picture_index];
    frame->payload[2] = ctx->bufptr_2[picture_index];

    frame->payload_size[0] = ctx->frame_size[0];
    frame->payload_size[1] = ctx->frame_size[1];
    frame->payload_size[2] = ctx->frame_size[2];
    frame->timestamp = ctx->timestamp[picture_index];

    return 0;
}

int nvmpi_decoder_close(nvmpictx *ctx) {

    ctx->mutex->lock();
    ctx->eos = true;
    ctx->mutex->unlock();

    ctx->dec->capture_plane.setStreamStatus(false);

    if (ctx->dec_capture_loop) {
        ctx->dec_capture_loop->join();
        delete ctx->dec_capture_loop;
        ctx->dec_capture_loop = nullptr;
    }

    if (ctx->dst_dma_fd != -1) {
        NvBufSurf::NvDestroy(ctx->dst_dma_fd);
        ctx->dst_dma_fd = -1;
    }

    for (int index = 0; index < ctx->numberCaptureBuffers; index++) {
        if (ctx->dmaBufferFileDescriptor[index] != 0) {
            int ret = NvBufSurf::NvDestroy(ctx->dmaBufferFileDescriptor[index]);
            TEST_ERROR(ret < 0, "Failed to Destroy NvBuffer", ret);
        }
    }

    delete ctx->dec;
    ctx->dec = nullptr;

    for (int index = 0; index < MAX_BUFFERS; index++) {
        delete[] ctx->bufptr_0[index];
        delete[] ctx->bufptr_1[index];
        delete[] ctx->bufptr_2[index];
    }

    delete ctx->mutex;
    ctx->mutex = nullptr;
    delete ctx->has_frame_cv;
    ctx->has_frame_cv = nullptr;
    delete ctx->frame_pools;
    ctx->frame_pools = nullptr;

    delete ctx;
    ctx = nullptr;

    return 0;
}


