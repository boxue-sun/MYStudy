#!/bin/bash -x
set -e
set -u
set -o pipefail

CPU_NUM=$(grep -c ^processor /proc/cpuinfo)
PREFIX=$(pwd)/..

rm -rf nv-codec-headers && git clone https://git.videolan.org/git/ffmpeg/nv-codec-headers.git
cd nv-codec-headers && git checkout n9.1.23.2 && sudo make install && cd -

[ -f ffmpeg-4.1.4.tar.gz ] || wget http://ffmpeg.org/releases/ffmpeg-4.1.4.tar.gz
rm -rf ffmpeg-4.1.4
tar zxvf ffmpeg-4.1.4.tar.gz
cd ffmpeg-4.1.4
git init
git add -A .
git commit -am "init"
git apply ../0001-baidu-internal-patch.patch

export PKG_CONFIG_PATH=/home/caros/3rd/baidu/adu-3rd/video-decoder/lib/pkgconfig
pkg-config --modversion ffnvcodec
CUDA_PATH=nvcc=$HOME/3rd/baidu/adu-3rd/cuda

./configure --prefix=$PREFIX --enable-shared --disable-stripping --enable-pic --extra-libs="-ldl -lva -lva-drm -llzma -lz -lvdpau -lpthread -lm -lx264 -lx265" --enable-gpl --enable-libx264 --enable-libx265 --enable-nonfree --enable-libtheora --enable-libvorbis --enable-avresample --cc=gcc-7 --cxx=g++-7 \
--extra-ldflags=-L$HOME/3rd/baidu/adu-3rd/cuda/lib64  \
--extra-cflags=-I$HOME/3rd/baidu/adu-3rd/cuda/include \
--disable-swresample        \
--enable-shared             \
--enable-cuda               \
--enable-nvenc              \
--enable-cuvid              \
--enable-nonfree            \
--enable-libnpp             \
--disable-htmlpages         \
--disable-manpages          \
--disable-podpages          \
--disable-txtpages          \
--enable-hwaccel=h264_nvdec,hevc_nvdec               \
--enable-hwaccel=mpeg2_nvdec,mpeg4_nvdec             \
--enable-parser=h264,hevc,mpegvideo,mpeg4video       \
--enable-protocol=tcp,file,rtmp,rtp,udp              \
--enable-decoder=h264,h264_cuvid,hevc,hevc_cuvid     \
--enable-decoder=mpeg2,mpeg2_cuvid,mpeg4,mpeg4_cuvid \
--enable-decoder=h264,h264_cuvid
make -j$CPU_NUM
make install
