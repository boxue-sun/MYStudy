#ifndef __LINUX_PLAYM4_H__
#define __LINUX_PLAYM4_H__ 
#ifdef __cplusplus
 extern "C"
 {
#endif
typedef unsigned int PLAYM4_HWND;
typedef void * PLAYM4_HWNDEX;
typedef void * PLAYM4_HDC;
#define PLAYM4_API 
#define __stdcall 
#ifndef CALLBACK
#define CALLBACK 
#endif
#define PLAYM4_MAX_SUPPORTS 500
#define MIN_WAVE_COEF -100
#define MAX_WAVE_COEF 100
#define TIMER_1 1
#define TIMER_2 2
#define BUF_VIDEO_SRC (1)
#define BUF_AUDIO_SRC (2)
#define BUF_VIDEO_RENDER (3)
#define BUF_AUDIO_RENDER (4)
#define BUF_VIDEO_DECODED (5)
#define BUF_AUDIO_DECODED (6)
#define PLAYM4_NOERROR 0
#define PLAYM4_PARA_OVER 1
#define PLAYM4_ORDER_ERROR 2
#define PLAYM4_TIMER_ERROR 3
#define PLAYM4_DEC_VIDEO_ERROR 4
#define PLAYM4_DEC_AUDIO_ERROR 5
#define PLAYM4_ALLOC_MEMORY_ERROR 6
#define PLAYM4_OPEN_FILE_ERROR 7
#define PLAYM4_CREATE_OBJ_ERROR 8
#define PLAYM4_BUF_OVER 11
#define PLAYM4_CREATE_SOUND_ERROR 12
#define PLAYM4_SET_VOLUME_ERROR 13
#define PLAYM4_SUPPORT_FILE_ONLY 14
#define PLAYM4_SUPPORT_STREAM_ONLY 15
#define PLAYM4_SYS_NOT_SUPPORT 16
#define PLAYM4_FILEHEADER_UNKNOWN 17
#define PLAYM4_VERSION_INCORRECT 18
#define PLAYM4_INIT_DECODER_ERROR 19
#define PLAYM4_CHECK_FILE_ERROR 20
#define PLAYM4_INIT_TIMER_ERROR 21
#define PLAYM4_BLT_ERROR 22
#define PLAYM4_OPEN_FILE_ERROR_MULTI 24
#define PLAYM4_OPEN_FILE_ERROR_VIDEO 25
#define PLAYM4_JPEG_COMPRESS_ERROR 26
#define PLAYM4_EXTRACT_NOT_SUPPORT 27
#define PLAYM4_EXTRACT_DATA_ERROR 28
#define PLAYM4_SECRET_KEY_ERROR 29
#define PLAYM4_DECODE_KEYFRAME_ERROR 30
#define PLAYM4_NEED_MORE_DATA 31
#define PLAYM4_INVALID_PORT 32
#define PLAYM4_NOT_FIND 33
#define PLAYM4_NEED_LARGER_BUFFER 34
#define PLAYM4_FAIL_UNKNOWN 99
#define PLAYM4_FEC_ERR_ENABLEFAIL 100
#define PLAYM4_FEC_ERR_NOTENABLE 101
#define PLAYM4_FEC_ERR_NOSUBPORT 102
#define PLAYM4_FEC_ERR_PARAMNOTINIT 103
#define PLAYM4_FEC_ERR_SUBPORTOVER 104
#define PLAYM4_FEC_ERR_EFFECTNOTSUPPORT 105
#define PLAYM4_FEC_ERR_INVALIDWND 106
#define PLAYM4_FEC_ERR_PTZOVERFLOW 107
#define PLAYM4_FEC_ERR_RADIUSINVALID 108
#define PLAYM4_FEC_ERR_UPDATENOTSUPPORT 109
#define PLAYM4_FEC_ERR_NOPLAYPORT 110
#define PLAYM4_FEC_ERR_PARAMVALID 111
#define PLAYM4_FEC_ERR_INVALIDPORT 112
#define PLAYM4_FEC_ERR_PTZZOOMOVER 113
#define PLAYM4_FEC_ERR_OVERMAXPORT 114
#define PLAYM4_FEC_ERR_ENABLED 115
#define PLAYM4_FEC_ERR_D3DACCENOTENABLE 116
#define PLAYM4_FEC_ERR_PLACETYPE 117
#define PLAYM4_FEC_ERR_CorrectType 118
#define PLAYM4_FEC_ERR_NULLWND 119
#define PLAYM4_FEC_ERR_PARA 120
#define MAX_DISPLAY_WND 4
#define DISPLAY_NORMAL 0x00000001
#define DISPLAY_QUARTER 0x00000002
#define DISPLAY_YC_SCALE 0x00000004
#define DISPLAY_NOTEARING 0x00000008
#define MAX_DIS_FRAMES 50
#define MIN_DIS_FRAMES 1
#define BY_FRAMENUM 1
#define BY_FRAMETIME 2
#define SOURCE_BUF_MAX 1024*100000
#define SOURCE_BUF_MIN 1024*50
#define STREAME_REALTIME 0
#define STREAME_FILE 1
#define T_AUDIO16 101
#define T_AUDIO8 100
#define T_UYVY 1
#define T_YV12 3
#define T_RGB32 7
#define SUPPORT_DDRAW 1
#define SUPPORT_BLT 2
#define SUPPORT_BLTFOURCC 4
#define SUPPORT_BLTSHRINKX 8
#define SUPPORT_BLTSHRINKY 16
#define SUPPORT_BLTSTRETCHX 32
#define SUPPORT_BLTSTRETCHY 64
#define SUPPORT_SSE 128
#define SUPPORT_MMX 256
#define FOURCC_HKMI 0x484B4D49
#define SYSTEM_NULL 0x0
#define SYSTEM_HIK 0x1
#define SYSTEM_MPEG2_PS 0x2
#define SYSTEM_MPEG2_TS 0x3
#define SYSTEM_RTP 0x4
#define SYSTEM_RTPHIK 0x401
#define VIDEO_NULL 0x0
#define VIDEO_H264 0x1
#define VIDEO_MPEG2 0x2
#define VIDEO_MPEG4 0x3
#define VIDEO_MJPEG 0x4
#define VIDEO_AVC264 0x0100
#define AUDIO_NULL 0x0000
#define AUDIO_ADPCM 0x1000
#define AUDIO_MPEG 0x2000
#define AUDIO_AAC 0x2001
#define AUDIO_RAW_DATA8 0x7000
#define AUDIO_RAW_UDATA16 0x7001
#define AUDIO_G711_U 0x7110
#define AUDIO_G711_A 0x7111
#define AUDIO_G722_1 0x7221
#define AUDIO_G723_1 0x7231
#define AUDIO_G726_U 0x7260
#define AUDIO_G726_A 0x7261
#define AUDIO_G726_16 0x7262
#define AUDIO_G729 0x7290
#define AUDIO_AMR_NB 0x3000
#define SYNCDATA_VEH 1
#define SYNCDATA_IVS 2
#define MOTION_FLOW_NONE 0
#define MOTION_FLOW_CPU 1
#define MOTION_FLOW_GPU 2
#define ENCRYPT_AES_3R_VIDEO 1
#define ENCRYPT_AES_10R_VIDEO 2
#define ENCRYPT_AES_3R_AUDIO 1
#define ENCRYPT_AES_10R_AUDIO 2
typedef struct tagSystemTime
{
    short wYear;
    short wMonth;
    short wDayOfWeek;
    short wDay;
    short wHour;
    short wMinute;
    short wSecond;
    short wMilliseconds;
}SYSTEMTIME;
typedef struct tagHKRect
{
    unsigned long left;
    unsigned long top;
    unsigned long right;
    unsigned long bottom;
}HKRECT;
typedef struct
{
 long long nFilePos;
    int nFrameNum;
    int nFrameTime;
    int nErrorFrameNum;
    SYSTEMTIME *pErrorTime;
    int nErrorLostFrameNum;
    int nErrorFrameSize;
}FRAME_POS,*PFRAME_POS;
typedef struct
{
    int nWidth;
    int nHeight;
    int nStamp;
    int nType;
    int nFrameRate;
    unsigned int dwFrameNum;
}FRAME_INFO;
typedef struct
{
    char *pDataBuf;
    int nSize;
    int nFrameNum;
    int bIsAudio;
    int nReserved;
}FRAME_TYPE;
typedef struct
{
    char *pDataBuf;
    int nSize;
    int nFrameNum;
    int bRsaRight;
    int nReserved;
}WATERMARK_INFO;
typedef struct SYNCDATA_INFO
{
    unsigned int dwDataType;
    unsigned int dwDataLen;
    unsigned char* pData;
} SYNCDATA_INFO;
#ifndef _HIK_MEDIAINFO_FLAG_
#define _HIK_MEDIAINFO_FLAG_ 
typedef struct _HIK_MEDIAINFO_
{
    unsigned int media_fourcc;
    unsigned short media_version;
    unsigned short device_id;
    unsigned short system_format;
    unsigned short video_format;
    unsigned short audio_format;
    unsigned char audio_channels;
    unsigned char audio_bits_per_sample;
    unsigned int audio_samplesrate;
    unsigned int audio_bitrate;
    unsigned char flag;
    unsigned char stream_tag;
    unsigned char reserved[14];
}HIK_MEDIAINFO;
#endif
typedef struct
{
    int nPort;
    char* pBuf;
    int nBufLen;
    int nWidth;
    int nHeight;
    int nStamp;
    int nType;
    void* nUser;
}DISPLAY_INFO;
typedef struct
{
    int nPort;
    char *pVideoBuf;
    int nVideoBufLen;
    char *pPriBuf;
    int nPriBufLen;
    int nWidth;
    int nHeight;
    int nStamp;
    int nType;
    void* nUser;
}DISPLAY_INFOEX;
typedef struct PLAYM4_SYSTEM_TIME
{
    unsigned int dwYear;
    unsigned int dwMon;
    unsigned int dwDay;
    unsigned int dwHour;
    unsigned int dwMin;
    unsigned int dwSec;
    unsigned int dwMs;
} PLAYM4_SYSTEM_TIME;
#ifndef CROP_PIC_INFO_TAG
#define CROP_PIC_INFO_TAG 
typedef struct
{
    unsigned char* pDataBuf;
    unsigned int dwPicSize;
    unsigned int dwBufSize;
    unsigned int dwPicWidth;
    unsigned int dwPicHeight;
    unsigned int dwReserve;
    HKRECT* pCropRect;
}CROP_PIC_INFO;
#endif
int PlayM4_GetPort(int* nPort);
int PlayM4_FreePort(int nPort);
int PlayM4_OpenFile(int nPort,char * sFileName);
int PlayM4_CloseFile(int nPort);
int PlayM4_SetStreamOpenMode(int nPort,unsigned int nMode);
int PlayM4_GetStreamOpenMode(int nPort);
int PlayM4_OpenStream(int nPort,unsigned char * pFileHeadBuf,unsigned int nSize,unsigned int nBufPoolSize);
int PlayM4_CloseStream(int nPort);
int PlayM4_Play(int nPort, PLAYM4_HWND hWnd);
int PlayM4_PlayEx(int nPort, PLAYM4_HWNDEX hWnd);
int PlayM4_Stop(int nPort);
int PlayM4_Pause(int nPort,unsigned int nPause);
int PlayM4_Fast(int nPort);
int PlayM4_Slow(int nPort);
int PlayM4_RefreshPlay(int nPort);
int PlayM4_InputData(int nPort,unsigned char * pBuf,unsigned int nSize);
int PlayM4_PlaySound(int nPort);
int PlayM4_StopSound();
int PlayM4_PlaySoundShare(int nPort);
int PlayM4_StopSoundShare(int nPort);
int PlayM4_SetVolume(int nPort,unsigned short nVolume);
unsigned short PlayM4_GetVolume(int nPort);
int PlayM4_OneByOne(int nPort);
int PlayM4_OneByOneBack(int nPort);
int PlayM4_SetPlayPos(int nPort,float fRelativePos);
float PlayM4_GetPlayPos(int nPort);
unsigned int PlayM4_GetFileTime(int nPort);
unsigned int PlayM4_GetPlayedTime(int nPort);
unsigned int PlayM4_GetPlayedFrames(int nPort);
unsigned int PlayM4_GetFileTotalFrames(int nPort);
unsigned int PlayM4_GetCurrentFrameRate(int nPort);
unsigned int PlayM4_GetCurrentFrameNum(int nPort);
unsigned int PlayM4_GetSpecialData(int nPort);
unsigned int PlayM4_GetAbsFrameNum(int nPort);
unsigned int PlayM4_GetFileHeadLength();
unsigned int PlayM4_GetSdkVersion();
unsigned int PlayM4_GetLastError(int nPort);
unsigned int PlayM4_GetPlayedTimeEx(int nPort);
int PlayM4_GetSystemTime(int nPort, PLAYM4_SYSTEM_TIME *pstSystemTime);
int PlayM4_GetFileTimeEx(int nPort, unsigned int* pStart, unsigned int* pStop, unsigned int* pRev);
int PlayM4_GetCurrentFrameRateEx(int nPort, float* pfFrameRate);
int PlayM4_GetPictureSize(int nPort,int *pWidth,int *pHeight);
int PlayM4_GetKeyFramePos(int nPort,unsigned int nValue, unsigned int nType, PFRAME_POS pFramePos);
int PlayM4_GetNextKeyFramePos(int nPort,unsigned int nValue, unsigned int nType, PFRAME_POS pFramePos);
int PlayM4_ConvertToBmpFile(char * pBuf,int nSize,int nWidth,int nHeight,int nType,char *sFileName);
int PlayM4_ConvertToJpegFile(char * pBuf,int nSize,int nWidth,int nHeight,int nType,char *sFileName);
int PlayM4_SetJpegQuality(int nQuality);
int PlayM4_GetBMP(int nPort,unsigned char * pBitmap,unsigned int nBufSize,unsigned int* pBmpSize);
int PlayM4_GetJPEG(int nPort,unsigned char * pJpeg,unsigned int nBufSize,unsigned int* pJpegSize);
int PlayM4_SetPlayedTimeEx(int nPort,unsigned int nTime);
int PlayM4_SetCurrentFrameNum(int nPort,unsigned int nFrameNum);
int PlayM4_SetDisplayRegion(int nPort,unsigned int nRegionNum, HKRECT *pSrcRect, PLAYM4_HWND hDestWnd, int bEnable);
int PlayM4_SetDisplayRegionOnWnd(int nPort,unsigned int nRegionNum, HKRECT *pSrcRect, int bEnable);
int PlayM4_SetDecodeFrameType(int nPort,unsigned int nFrameType);
int PlayM4_SetSecretKey(int nPort, int lKeyType, char *pSecretKey, int lKeyLen);
int PlayM4_SetDecCBStream(int nPort,unsigned int nStream);
int PlayM4_SetDecCallBackMend(int nPort,void (CALLBACK* DecCBFun)(int nPort,char * pBuf,int nSize,FRAME_INFO * pFrameInfo, void* nUser,int nReserved2), void* nUser);
int PlayM4_SetDecCallBackExMend(int nPort, void (CALLBACK* DecCBFun)(int nPort, char* pBuf, int nSize, FRAME_INFO* pFrameInfo, void* nUser, int nReserved2), char* pDest, int nDestSize, void* nUser);
int PlayM4_SetDisplayCallBack(int nPort,void (CALLBACK* DisplayCBFun)(int nPort,char * pBuf,int nSize,int nWidth,int nHeight,int nStamp,int nType,int nReserved));
int PlayM4_SetDisplayCallBackEx(int nPort,void (CALLBACK* DisplayCBFun)(DISPLAY_INFO *pstDisplayInfo), void* nUser);
int PlayM4_SetFileRefCallBack(int nPort, void (CALLBACK *pFileRefDone)(unsigned int nPort,void* nUser),void* nUser);
int PlayM4_SetEncTypeChangeCallBack(int nPort, void(CALLBACK *funEncChange)(int nPort, void* nUser), void* nUser);
int PlayM4_SetCheckWatermarkCallBack(int nPort, void(CALLBACK* funCheckWatermark)(int nPort, WATERMARK_INFO* pWatermarkInfo, void* nUser), void* nUser);
int PlayM4_SetFileEndCallback(int nPort, void(CALLBACK*FileEndCallback)(int nPort, void *pUser), void *pUser);
int PlayM4_ResetSourceBuffer(int nPort);
int PlayM4_SetDisplayBuf(int nPort, unsigned int nNum);
int PlayM4_ResetBuffer(int nPort,unsigned int nBufType);
unsigned int PlayM4_GetSourceBufferRemain(int nPort);
unsigned int PlayM4_GetDisplayBuf(int nPort);
unsigned int PlayM4_GetBufferValue(int nPort,unsigned int nBufType);
int PlayM4_GetRefValue(int nPort,unsigned char *pBuffer, unsigned int *pSize);
int PlayM4_SetRefValue(int nPort,unsigned char *pBuffer, unsigned int nSize);
int PlayM4_GetRefValueEx(int nPort,unsigned char *pBuffer, unsigned int *pSize);
int PlayM4_RegisterDrawFun(int nPort,void (CALLBACK* DrawFun)(int nPort,PLAYM4_HDC hDc,void* nUser),void* nUser);
int PlayM4_ThrowBFrameNum(int nPort,unsigned int nNum);
int PlayM4_SkipErrorData(int nPort, int bSkip);
int PlayM4_ReversePlay(int nPort);
#ifndef PLAYM4_SESSION_INFO_TAG
#define PLAYM4_SESSION_INFO_TAG 
#define PLAYM4_PROTOCOL_RTSP 1
#define PLAYM4_SESSION_INFO_SDP 1
typedef struct _PLAYM4_SESSION_INFO_
{
    int nSessionInfoType;
    int nSessionInfoLen;
    unsigned char* pSessionInfoData;
} PLAYM4_SESSION_INFO;
#endif
PLAYM4_API int __stdcall PlayM4_OpenStreamAdvanced(int nPort, int nProtocolType, PLAYM4_SESSION_INFO* pstSessionInfo, unsigned int nBufPoolSize);
#define R_ANGLE_0 -1
#define R_ANGLE_L90 0
#define R_ANGLE_R90 1
#define R_ANGLE_180 2
PLAYM4_API int __stdcall PlayM4_SetRotateAngle(int nPort, unsigned int nRegionNum, unsigned int dwType);
#ifndef PLAYM4_ADDITION_INFO_TAG
#define PLAYM4_ADDITION_INFO_TAG 
typedef struct _PLAYM4_ADDITION_INFO_
{
    unsigned char* pData;
    unsigned int dwDatalen;
    unsigned int dwDataType;
    unsigned int dwTimeStamp;
} PLAYM4_ADDITION_INFO;
#endif
PLAYM4_API int __stdcall PlayM4_SetSycGroup(int nPort, unsigned int dwGroupIndex);
PLAYM4_API int __stdcall PlayM4_SetSycStartTime(int nPort, PLAYM4_SYSTEM_TIME *pstSystemTime);
#ifndef FISH_EYE_TAG
#define FISH_EYE_TAG 
typedef enum tagFECPlaceType
{
    FEC_PLACE_WALL = 0x1,
    FEC_PLACE_FLOOR = 0x2,
    FEC_PLACE_CEILING = 0x3,
}FECPLACETYPE;
typedef enum tagFECCorrectType
{
 FEC_CORRECT_NULL = 0x0,
 FEC_CORRECT_PTZ = 0x100,
 FEC_CORRECT_180 = 0x200,
 FEC_CORRECT_360 = 0x300,
    FEC_CORRECT_LAT = 0x400,
 FEC_CORRECT_SEMISPHERE = 0x500,
    FEC_CORRECT_CYLINDER = 0x0600,
    FEC_CORRECT_CYLINDER_SPLIT = 0x0700,
    FEC_CORRECT_PLANET = 0x0800,
    FEC_CORRECT_ARCSPHERE_HORIZONTAL = 0x0900,
    FEC_CORRECT_ARCSPHERE_VERTICAL = 0x0A00,
}FECCORRECTTYPE;
typedef enum tagFECCorrectEffect
{
    FEC_CORRECT_EFFECT_BACK_FACE_CULLING = 0x100,
}FECCORRECTEFFECT;
typedef struct tagCycleParam
{
    float fRadiusLeft;
    float fRadiusRight;
    float fRadiusTop;
    float fRadiusBottom;
}CYCLEPARAM;
typedef struct tagPTZParam
{
    float fPTZPositionX;
    float fPTZPositionY;
}PTZPARAM;
typedef enum tagFECShowMode
{
    FEC_PTZ_OUTLINE_NULL,
    FEC_PTZ_OUTLINE_RECT,
    FEC_PTZ_OUTLINE_RANGE,
}FECSHOWMODE;
#define FEC_UPDATE_RADIUS 0x1
#define FEC_UPDATE_PTZZOOM 0x2
#define FEC_UPDATE_WIDESCANOFFSET 0x4
#define FEC_UPDATE_PTZPARAM 0x8
#define FEC_UPDATT_PTZCOLOR 0x10
typedef struct tagFECColor
{
    unsigned char nR;
    unsigned char nG;
    unsigned char nB;
    unsigned char nAlpha;
}FECCOLOR;
typedef struct tagFECParam
{
 unsigned int nUpDateType;
 unsigned int nPlaceAndCorrect;
 PTZPARAM stPTZParam;
 CYCLEPARAM stCycleParam;
 float fZoom;
 float fWideScanOffset;
    FECCOLOR stPTZColor;
 int nResver[15];
}FISHEYEPARAM;
#define FEC_JPEG 0
#define FEC_BMP 1
typedef enum tagPLAYM4HRViewParamType
{
    PLAYM4_HR_VPT_ROTATION_X = 0x1,
    PLAYM4_HR_VPT_ROTATION_Y = 0x2,
    PLAYM4_HR_VPT_SCALE = 0x3,
}PLAYM4HRVIEWPARAMTYPE;
typedef enum tagPLAYM4FEC3DModelParam
{
    PLAYM4_FEC_3DMP_CYLINDER_HEIGHT = 0x1,
    PLAYM4_FEC_3DMP_CYLINDER_RADIUS = 0x2,
}PLAYM4FEC3DMODELPARAM;
typedef enum tagPLAYM4FECSpecialViewType
{
    PLAYM4_FEC_SVT_EDGE = 0x1
}PLAYM4FECSPECIALVIEWTYPE;
#endif
typedef void (__stdcall * FISHEYE_CallBack )( void* pUser , unsigned int nPort , unsigned int nCBType , void * hDC , unsigned int nWidth , unsigned int nHeight);
PLAYM4_API int __stdcall PlayM4_FEC_Enable(int nPort);
PLAYM4_API int __stdcall PlayM4_FEC_Disable(int nPort);
PLAYM4_API int __stdcall PlayM4_FEC_GetPort(int nPort , unsigned int* nSubPort , FECPLACETYPE emPlaceType , FECCORRECTTYPE emCorrectType);
PLAYM4_API int __stdcall PlayM4_FEC_DelPort(int nPort , unsigned int nSubPort);
PLAYM4_API int __stdcall PlayM4_FEC_SetParam(int nPort , unsigned int nSubPort , FISHEYEPARAM * pPara);
PLAYM4_API int __stdcall PlayM4_FEC_GetParam(int nPort , unsigned int nSubPort , FISHEYEPARAM * pPara);
PLAYM4_API int __stdcall PlayM4_FEC_SetWnd(int nPort , unsigned int nSubPort , void * hWnd);
PLAYM4_API int __stdcall PlayM4_FEC_SetCallBack(int nPort , unsigned int nSubPort , FISHEYE_CallBack cbFunc , void * pUser);
PLAYM4_API int __stdcall PlayM4_FEC_Capture(int nPort, unsigned int nSubPort , unsigned int nType, char *pFileName);
PLAYM4_API int __stdcall PlayM4_FEC_GetCurrentPTZPort(int nPort, float fPositionX,float fPositionY, unsigned int *pnPort);
PLAYM4_API int __stdcall PlayM4_FEC_SetCurrentPTZPort(int nPort, unsigned int nSubPort);
PLAYM4_API int __stdcall PlayM4_FEC_SetPTZOutLineShowMode(int nPort,FECSHOWMODE nPTZShowMode);
PLAYM4_API int __stdcall PlayM4_FEC_GetViewParam(int nPort, unsigned int nSubPort, PLAYM4HRVIEWPARAMTYPE enViewParamType, float* fValue);
PLAYM4_API int __stdcall PlayM4_FEC_SetViewParam(int nPort, unsigned int nSubPort, PLAYM4HRVIEWPARAMTYPE enViewParamType, float fValue);
PLAYM4_API bool __stdcall PlayM4_FEC_SetDisplayRegion(int nPort, unsigned int nSubPort,unsigned int nType, unsigned int nRegionNum, HKRECT *pSrcRect, PLAYM4_HWND hDestWnd, int bEnable);
PLAYM4_API bool __stdcall PlayM4_FEC_SetCorrectEffect(int nPort, unsigned int nSubPort, FECCORRECTEFFECT nCorrectEffect, float fValue);
PLAYM4_API bool __stdcall PlayM4_FEC_Set3DModelParam(int nPort, unsigned int nSubPort, PLAYM4FEC3DMODELPARAM enType, float fValue);
PLAYM4_API bool __stdcall PlayM4_FEC_GetSpecialViewParam(int nPort, unsigned int nSubPort, PLAYM4FECSPECIALVIEWTYPE enSVType, PLAYM4HRVIEWPARAMTYPE enVPType, float* pValue);
#ifndef PLAYM4_HIKVIE_TAG
#define PLAYM4_HIKVIE_TAG 
typedef struct _PLAYM4_VIE_DYNPARAM_
{
    int moduFlag;
    int brightVal;
    int contrastVal;
    int colorVal;
    int toneScale;
    int toneGain;
    int toneOffset;
    int toneColor;
    int dehazeLevel;
    int dehazeTrans;
    int dehazeBright;
    int denoiseLevel;
    int usmAmount;
    int usmRadius;
    int usmThreshold;
    int deblockLevel;
    int lensWarp;
    int lensZoom;
} PLAYM4_VIE_PARACONFIG;
typedef enum _PLAYM4_VIE_MODULES
{
    PLAYM4_VIE_MODU_ADJ = 0x00000001,
    PLAYM4_VIE_MODU_EHAN = 0x00000002,
    PLAYM4_VIE_MODU_DEHAZE = 0x00000004,
    PLAYM4_VIE_MODU_DENOISE = 0x00000008,
    PLAYM4_VIE_MODU_SHARPEN = 0x00000010,
    PLAYM4_VIE_MODU_DEBLOCK = 0x00000020,
    PLAYM4_VIE_MODU_CRB = 0x00000040,
    PLAYM4_VIE_MODU_LENS = 0x00000080,
}PLAYM4_VIE_MODULES;
#endif
PLAYM4_API int __stdcall PlayM4_VIE_SetModuConfig(int nPort, int nModuFlag, int bEnable);
PLAYM4_API int __stdcall PlayM4_VIE_SetRegion(int nPort, int nRegNum, HKRECT* pRect);
PLAYM4_API int __stdcall PlayM4_VIE_GetModuConfig(int nPort, int* pdwModuFlag);
PLAYM4_API int __stdcall PlayM4_VIE_SetParaConfig(int nPort, PLAYM4_VIE_PARACONFIG* pParaConfig);
PLAYM4_API int __stdcall PlayM4_VIE_GetParaConfig(int nPort, PLAYM4_VIE_PARACONFIG* pParaConfig);
typedef enum _PLAYM4_PRIDATA_RENDER
{
    PLAYM4_RENDER_ANA_INTEL_DATA = 0x00000001,
    PLAYM4_RENDER_MD = 0x00000002,
    PLAYM4_RENDER_ADD_POS = 0x00000004,
    PLAYM4_RENDER_ADD_PIC = 0x00000008,
    PLAYM4_RENDER_FIRE_DETCET = 0x00000010,
    PLAYM4_RENDER_TEM = 0x00000020,
}PLAYM4_PRIDATA_RENDER;
typedef enum _PLAYM4_FIRE_ALARM
{
    PLAYM4_FIRE_FRAME_DIS = 0x00000001,
    PLAYM4_FIRE_MAX_TEMP = 0x00000002,
    PLAYM4_FIRE_MAX_TEMP_POSITION = 0x00000004,
    PLAYM4_FIRE_DISTANCE = 0x00000008,
}PLAYM4_FIRE_ALARM;
typedef enum _PLAYM4_TEM_FLAG
{
    PLAYM4_TEM_REGION_BOX = 0x00000001,
    PLAYM4_TEM_REGION_LINE = 0x00000002,
    PLAYM4_TEM_REGION_POINT = 0x00000004,
}PLAYM4_TEM_FLAG;
PLAYM4_API int __stdcall PlayM4_RenderPrivateData(int nPort, int nIntelType, int bTrue);
PLAYM4_API int __stdcall PlayM4_RenderPrivateDataEx(int nPort, int nIntelType, int nSubType, int bTrue);
typedef struct{
    long nVideoEncryptType;
    long nAudioEncryptType;
    long nSetSecretKey;
}ENCRYPT_INFO;
PLAYM4_API int __stdcall PlayM4_SetEncryptTypeCallBack(int nPort, unsigned int nType, void (CALLBACK* EncryptTypeCBFun)(int nPort, ENCRYPT_INFO* pEncryptInfo, void* nUser, int nReserved2), void* nUser);
#define PLAYM4_MEDIA_HEAD 1
#define PLAYM4_VIDEO_DATA 2
#define PLAYM4_AUDIO_DATA 3
#define PLAYM4_PRIVT_DATA 4
typedef struct
{
    long nType;
    long nStamp;
    long nFrameNum;
    long nBufLen;
    char* pBuf;
    PLAYM4_SYSTEM_TIME stSysTime;
}RECORD_DATA_INFO;
PLAYM4_API int __stdcall PlayM4_SetPreRecordFlag(int nPort, int bFlag);
PLAYM4_API int __stdcall PlayM4_SetPreRecordCallBack(int nPort, void (CALLBACK* PreRecordCBfun)(int nPort, RECORD_DATA_INFO* pRecordDataInfo, void* pUser), void* pUser);
typedef struct
{
    long lDataType;
    long lDataStrVersion;
    long lDataTimeStamp;
    long lDataLength;
    char* pData;
}AdditionDataInfo;
PLAYM4_API int __stdcall PlayM4_SetAdditionDataCallBack(int nPort, unsigned int nSyncType, void (CALLBACK* AdditionDataCBFun)(int nPort, AdditionDataInfo* pstAddDataInfo, void* pUser), void* pUser);
PLAYM4_API int __stdcall PlayM4_GetStreamAdditionalInfo(int nPort, int lType, unsigned char* pInfo, int* plLen);
#define PLAYM4_SOURCE_MODULE 0
#define PLAYM4_DEMUX_MODULE 1
#define PLAYM4_DECODE_MODULE 2
#define PLAYM4_RENDER_MODULE 3
#define PLAYM4_RTINFO_HARDDECODE_ERROR 0
#define PLAYM4_RTINFO_SOFTDECODE_ERROR 1
#define PLAYM4_RTINFO_MEDIAHEADER_ERROR 2
#define PLAYM4_RTINFO_SWITCH_SOFT_DEC 3
#define PLAYM4_RTINFO_ALLOC_MEMORY_ERROR 4
#define PLAYM4_RTINFO_ENCRYPT_ERROR 5
#define PLAYM4_RTINFO_RENDER_OVER 8
#define PLAYM4_RTINFO_ERR_PRESENT 16
#define PLAYM4_RTINFO_IDMX_DATA_ERROR 32
#define PLAYM4_RTINFO_DECODE_PARAM_ERROR 64
#define PLAYM4_RTINFO_SOFTDECODE_DATA_ERROR 128
typedef struct
{
    int nRunTimeModule;
    int nStrVersion;
    int nFrameTimeStamp;
    int nFrameNum;
    int nErrorCode;
    unsigned char reserved[12];
}RunTimeInfo;
PLAYM4_API int __stdcall PlayM4_SetRunTimeInfoCallBackEx(int nPort, int nModule, void (CALLBACK* RunTimeInfoCBFun)(int nPort, RunTimeInfo* pstRunTimeInfo, void* pUser), void* pUser);
PLAYM4_API int __stdcall PlayM4_SetRunTimeInfoCallbackType(int nPort, int nModule, unsigned int nType, int nFlag);
#ifndef PLAYM4_HIKD3D11_TAG
#define PLAYM4_HIKD3D11_TAG 
typedef struct _tagD3D11_PIC_INFO_
{
    unsigned int nPicMode;
    unsigned char* pBuf;
    unsigned int nBufSize;
    unsigned int* pPicSize;
    unsigned int nPicWidth;
    unsigned int nPicHeight;
    unsigned char chReserve[8];
}D3D_PIC_INFO;
typedef enum tagPLAYM4PostProcType
{
    PLAYM4_PPT_BRIGHTNESS = 0x1,
    PLAYM4_PPT_HUE = 0x2,
    PLAYM4_PPT_SATURATION = 0x3,
    PLAYM4_PPT_CONTRAST = 0x4,
    PLAYM4_PPT_SHARPNESS = 0x5,
}PLAYM4PostProcType;
#endif
PLAYM4_API int __stdcall PlayM4_GetD3DCapture(int nPort, unsigned int nType, D3D_PIC_INFO* pstPicInfo);
PLAYM4_API int __stdcall PlayM4_SetD3DPostProcess(int nPort, PLAYM4PostProcType nPostType, float fValue);
PLAYM4_API int __stdcall PlayM4_GetD3DPostProcess(int nPort, PLAYM4PostProcType nPostType, float* fValue);
PLAYM4_API int __stdcall PlayM4_SetConfigFontPath(int nPort, char* pFontPath);
PLAYM4_API int __stdcall PlayM4_GetMpOffset(int nPort, int nTime, int* nOffset);
PLAYM4_API bool __stdcall PlayM4_SetSupplementaryTimeZone(int nPort, int nTimeZone);
PLAYM4_API bool __stdcall PlayM4_GetSupplementaryTimeZone(int nPort, int* pTimeZone);
PLAYM4_API int __stdcall PlayM4_WndResolutionChange(int nPort);
PLAYM4_API int __stdcall PlayM4_SetRunTimeInfoCallBack(int nPort, void (CALLBACK* RunTimeInfoCBFun)(int nPort, RunTimeInfo* pstRunTimeInfo, void* pUser), void* pUser);
int PlayM4_RigisterDrawFun(int nPort,void (CALLBACK* DrawFun)(int nPort,PLAYM4_HDC hDc,void* nUser),void* nUser);
int PlayM4_SetDecCallBack(int nPort,void (CALLBACK* DecCBFun)(int nPort,char* pBuf,int nSize,FRAME_INFO * pFrameInfo, void* nReserved1,int nReserved2));
int PlayM4_SetDecCallBackEx(int nPort,void (CALLBACK* DecCBFun)(int nPort,char * pBuf,int nSize,FRAME_INFO * pFrameInfo, void* nReserved1,int nReserved2), char* pDest, int nDestSize);
int PlayM4_SetTimerType(int nPort,unsigned int nTimerType,unsigned int nReserved);
int PlayM4_GetTimerType(int nPort,unsigned int *pTimerType,unsigned int *pReserved);
int PlayM4_SetDisplayMode(int nPort, unsigned int dwType);
int PlayM4_SetVideoWindow(int nPort, unsigned int nRegionNum, PLAYM4_HWND hWnd);
int PlayM4_InitDDraw(PLAYM4_HWND hWnd);
int PlayM4_RealeseDDraw();
#if (WINVER >= 0x0400)
int PlayM4_InitDDrawDevice();
void PlayM4_ReleaseDDrawDevice();
int PlayM4_SetDDrawDevice(int nPort, unsigned int nDeviceNum);
int PlayM4_SetDDrawDeviceEx(int nPort,unsigned int nRegionNum,unsigned int nDeviceNum);
int PlayM4_GetDDrawDeviceInfo(unsigned int nDeviceNum, char* lpDriverDescription, unsigned int nDespLen, char* lpDriverName, unsigned int nNameLen, HMONITOR* hhMonitor);
int PlayM4_GetCapsEx(unsigned int nDDrawDeviceNum);
unsigned int PlayM4_GetDDrawDeviceTotalNums();
#endif
int PlayM4_GetCaps();
int PlayM4_OpenStreamEx(int nPort, unsigned char* pFileHeadBuf, unsigned int nSize, unsigned int nBufPoolSize);
int PlayM4_CloseStreamEx(int nPort);
int PlayM4_InputVideoData(int nPort, unsigned char* pBuf, unsigned int nSize);
int PlayM4_InputAudioData(int nPort, unsigned char* pBuf, unsigned int nSize);
int PlayM4_GetFileSpecialAttr(int nPort, unsigned int* pTimeStamp, unsigned int* pFileNum, unsigned int* pReserved);
int PlayM4_GetOverlayMode(int nPort);
int PlayM4_SetOverlayFlipMode(int nPort, int bTrue);
int PlayM4_SetPicQuality(int nPort, int bHighQuality);
int PlayM4_GetPictureQuality(int nPort, int* bHighQuality);
int PlayM4_ResetSourceBufFlag(int nPort);
int PlayM4_SetDisplayType(int nPort, int nType);
int PlayM4_GetDisplayType(int nPort);
int PlayM4_SyncToAudio(int nPort, int bSyncToAudio);
int PlayM4_RefreshPlayEx(int nPort, unsigned int nRegionNum);
int PlayM4_AdjustWaveAudio(int nPort, int nCoefficient);
int PlayM4_SetPlayMode(int nPort, int bNormal);
int PlayM4_SetColor(int nPort, unsigned int nRegionNum, int nBrightness, int nContrast, int nSaturation, int nHue);
int PlayM4_GetColor(int nPort, unsigned int nRegionNum, int* pBrightness, int* pContrast, int* pSaturation, int* pHue);
int PlayM4_SetImageSharpen(int nPort, unsigned int nLevel);
int PlayM4_SetDeflash(int nPort, int bDefalsh);
int PlayM4_CheckDiscontinuousFrameNum(int nPort, int bCheck);
int PlayM4_SetFileEndMsg(int nPort, PLAYM4_HWND hWnd, unsigned int nMsg);
int PlayM4_SetVerifyCallBack(int nPort, unsigned int nBeginTime, unsigned int nEndTime, void (__stdcall* funVerify)(int nPort, FRAME_POS* pFilePos, unsigned int bIsVideo, unsigned int nUser), unsigned int nUser);
int PlayM4_SetEncChangeMsg(int nPort, PLAYM4_HWND hWnd, unsigned int nMsg);
int PlayM4_SetGetUserDataCallBack(int nPort, void(CALLBACK* funGetUserData)(int nPort, unsigned char* pUserBuf, unsigned int nBufLen, unsigned int nUser), unsigned int nUser);
int PlayM4_SetSourceBufCallBack(int nPort, unsigned int nThreShold, void (CALLBACK* SourceBufCallBack)(int nPort, unsigned int nBufSize, unsigned int dwUser, void* pResvered), unsigned int dwUser, void* pReserved);
int PlayM4_GetOriginalFrameCallBack(int nPort, int bIsChange, int bNormalSpeed, int nStartFrameNum, int nStartStamp, int nFileHeader, void(CALLBACK *funGetOrignalFrame)(int nPort, FRAME_TYPE* frameType, int nUser), int nUser);
int PlayM4_GetThrowBFrameCallBack(int nPort, void(CALLBACK* funThrowBFrame)(int nPort, unsigned int nBFrame, unsigned int nUser), unsigned int nUser);
int PlayM4_SetAudioCallBack(int nPort, void (__stdcall* funAudio)(int nPort, char* pAudioBuf, int nSize, int nStamp, int nType, int nUser), int nUser);
PLAYM4_API int __stdcall PlayM4_MotionFlow(int nPort, unsigned int dwAdjustType);
#ifdef __cplusplus
    }
#endif
#endif
