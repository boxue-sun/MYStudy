#ifndef _ANALYZEDATA_DEFINE_H_
#define _ANALYZEDATA_DEFINE_H_ 
#ifdef WIN32
#ifndef HK_WIN32
#define HK_WIN32 WIN32
#endif
#endif
#ifdef __linux__
#ifndef HK_LINUX
#define HK_LINUX __linux__
#endif
#endif
#ifdef __APPLE__
#ifndef HK_APPLE
#define HK_APPLE __APPLE__
#endif
#endif
#ifdef HK_WIN32
#ifdef _WINDLL
#define ANALYZEDATA_API extern "C" _declspec(dllexport)
#else
#define ANALYZEDATA_API extern "C" _declspec(dllimport)
#endif
#endif
#ifdef HK_LINUX
#ifndef ANALYZEDATA_API
#define ANALYZEDATA_API 
#endif
#ifndef __stdcall
#define __stdcall 
#endif
#endif
#ifdef HK_APPLE
#ifndef ANALYZEDATA_API
#define ANALYZEDATA_API 
#endif
#ifndef __stdcall
#define __stdcall 
#endif
#endif
#define FILE_HEAD 0
#define VIDEO_I_FRAME 1
#define VIDEO_B_FRAME 2
#define VIDEO_P_FRAME 3
#define AUDIO_PACKET 10
#define PRIVT_PACKET 11
#define HIK_H264_E_FRAME (1 << 6)
#define ERROR_NOOBJECT -1
#define ERROR_NO 0
#define ERROR_OVERBUF 1
#define ERROR_PARAMETER 2
#define ERROR_CALL_ORDER 3
#define ERROR_ALLOC_MEMORY 4
#define ERROR_OPEN_FILE 5
#define ERROR_MEMORY 6
#define ERROR_SUPPORT 7
#define ERROR_NODATA 8
#define ERROR_NEED_MOREDATA 9
#define ERROR_UNKNOWN 99
#define ANALYZE_NORMAIL 0
#define ANALYZE_KEY_FRAME 1
#define ANALYZE_TEMPORAL_LAYER_0 2
#define ANALYZE_TEMPORAL_LAYER_1 3
#define ANALYZE_ENCAPSULATED_DATA 0
#define ANALYZE_RAW_DATA 1
#define ANALYZE_FAST_CHECK 2
#define ANALYZE_SECRET_PACKET_RES 0x00
#define ANALYZE_SECRET_PACKET_FUA 0x01
#define ANALYZE_SECRET_ARITH_NONE 0x00
#define ANALYZE_SECRET_ARITH_AES 0x01
#define ANALYZE_SECRET_TYPE_ZERO 0x00
#define ANALYZE_SECRET_TYPE_16B 0x01
#define ANALYZE_SECRET_TYPE_4KB 0x02
#define ANALYZE_SECRET_ROUND00 0x00
#define ANALYZE_SECRET_ROUND03 0x01
#define ANALYZE_SECRET_ROUND10 0x02
#define ANALYZE_SECRET_KEYLEN000 0x00
#define ANALYZE_SECRET_KEYLEN128 0x01
#define ANALYZE_SECRET_KEYLEN192 0x02
#define ANALYZE_SECRET_KEYLEN256 0x03
typedef enum {
    ANALYZE_NONE = 0x00,
    ANALYZE_ITS_AID_INFO_V2 = 0x10,
    ANALYZE_ITS_TPS_INFO_V2 = 0x11,
    ANALYZE_ITS_TARGET_LIST = 0x12,
    ANALYZE_ITS_TPS_RULE_LIST = 0x13,
    ANALYZE_VCA_TARGET_LIST = 0x20,
    ANALYZE_VCA_ALERT = 0x21,
    ANALYZE_VCA_RULE_LIST = 0x22,
    ANALYZE_VCA_EVT_INFO_LIST = 0x23,
    ANALYZE_FACE_IDENTIFICATION = 0x30,
    ANALYZE_FACE_DETECT_RULE = 0x31,
    INTELLIGENT_IVS_INDEX = 0x40,
    ANALYZE_INTEL_UNKNOWN = 0x99
} INTELLIGENT_DATA_TYPE;
typedef enum {
    ANALYZE_RTP_PACKET_NUM = 0x10,
    ANALYZE_RTP_HEADER = 0x11,
    ANALYZE_MPEG_PACKET_PSH = 0x20,
    ANALYZE_MPEG_PACKET_PSM = 0x21,
    ANALYZE_MPEG_PACKET_PES = 0x22,
    ANALYZE_TS_HEADER = 0x30,
    ANALYZE_MPEG_PACKET_PAT = 0x31,
    ANALYZE_MPEG_PACKET_PMT = 0x32,
    ANALYZE_REDUNDANT = 0x40,
    ANALYZE_STREAM_HEADER = 0x50,
    ANALYZE_ERROR_UNKNOWN = 0x99,
} STREAM_ERROR_TYPE;
typedef struct _ANA_ERROR_INFOR_ {
    unsigned int nErrorType;
    unsigned char *pHeaderData;
    unsigned int Reserved[6];
} ANA_ERROR_INFOR;
typedef struct {
    unsigned int nVideoFormat;
    unsigned int nTotalTtime;
    unsigned int nWidth;
    unsigned int nHeight;
    unsigned int nFrameRate;
    unsigned int Reserved[3];
} ANA_VIDEO_INFO;
typedef struct {
    unsigned short nAudioFormat;
    unsigned char nAudioChannels;
    unsigned char nAudioBitsPerSample;
    unsigned int nAudioSamplesRate;
    unsigned int nAudioBitRate;
    unsigned int nTotalTime;
    unsigned int Reserved[4];
} ANA_AUDIO_INFO;
typedef struct _PACKET_INFO {
    unsigned int dwTimeStamp;
    unsigned int nYear;
    unsigned int nMonth;
    unsigned int nDay;
    unsigned int nHour;
    unsigned int nMinute;
    unsigned int nSecond;
    unsigned int nPacketType;
    unsigned int dwPacketSize;
    unsigned char *pPacketBuffer;
} PACKET_INFO;
typedef struct _HIK_MFI_HEADER_ {
    unsigned char stream_type;
    unsigned char frame_type;
    unsigned char frame_sequence;
    unsigned char frame_sum;
    unsigned int frame_len;
    unsigned char reserved[4];
} HIK_MFI_HEADER;
typedef struct _PACKET_INFO_EX {
    unsigned short uWidth;
    unsigned short uHeight;
    unsigned int dwTimeStamp;
    unsigned int dwTimeStampHigh;
    unsigned int nYear;
    unsigned int nMonth;
    unsigned int nDay;
    unsigned int nHour;
    unsigned int nMinute;
    unsigned int nSecond;
    unsigned int nMillisecond;
    unsigned int dwFrameNum;
    unsigned int dwFrameRate;
    unsigned int dwFlag;
    unsigned int dwFilePos;
    unsigned int nPacketType;
    unsigned int dwPacketSize;
    unsigned char *pPacketBuffer;
    unsigned int dwEncrypted;
    unsigned int dwPacketType;
    unsigned int dwEncryptArith;
    unsigned int dwEncryptRound;
    unsigned int dwKeyLen;
    unsigned int dwEncryptType;
    unsigned int Reserved[6];
} PACKET_INFO_EX;
typedef struct _ANA_FILE_INFO_ {
    unsigned int system_format;
    ANA_VIDEO_INFO stVideoInfo;
    ANA_AUDIO_INFO stAudioInfo;
    unsigned int Reserved[7];
} ANA_FILE_INFO;
#endif
