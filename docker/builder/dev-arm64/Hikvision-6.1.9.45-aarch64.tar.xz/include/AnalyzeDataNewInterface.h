#ifndef _ANALYZEDATA_NEW_INTERFACE_H_
#define _ANALYZEDATA_NEW_INTERFACE_H_ 
#include "AnalyzeDataDefine.h"
#ifdef __cplusplus
extern "C"
{
#endif
ANALYZEDATA_API void *__stdcall HIKANA_CreateStreamEx(unsigned long dwSize, unsigned char *pHeader);
ANALYZEDATA_API void __stdcall HIKANA_Destroy(void *hHandle);
ANALYZEDATA_API int __stdcall HIKANA_InputData(void *hHandle, unsigned char *pBuffer, unsigned long dwSize);
ANALYZEDATA_API int __stdcall HIKANA_GetOnePacketEx(void *hHandle, PACKET_INFO_EX *pstPacket);
ANALYZEDATA_API int __stdcall HIKANA_ClearBuffer(void *hHandle);
ANALYZEDATA_API int __stdcall HIKANA_GetRemainData(void *hHandle, unsigned char *pData, unsigned long *pdwSize);
ANALYZEDATA_API int __stdcall HIKANA_SetAnalyzeFrameType(void *hHandle, unsigned int nType);
ANALYZEDATA_API int __stdcall HIKANA_SetOutputPacketType(void *hHandle, unsigned int nType);
ANALYZEDATA_API int __stdcall HIKANA_RegistStreamInforCB(void *hHandle,
                                                         void (__stdcall *pErroeInforCB)(ANA_ERROR_INFOR *pErrorInfor,
                                                                                         void *pUser),
                                                         void *pUser);
ANALYZEDATA_API unsigned int __stdcall HIKANA_GetLastErrorH(void *hHandle);
ANALYZEDATA_API int __stdcall HIKANA_GetVersion();
ANALYZEDATA_API void *__stdcall HIKANA_CreateHandleByPath(unsigned long dwSize, const char *szFilePath);
ANALYZEDATA_API int __stdcall HIKANA_GetFileInfo(void *hHandle, ANA_FILE_INFO *pstFileInfo);
#ifdef __cplusplus
}
#endif
#endif
