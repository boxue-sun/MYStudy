#!/usr/bin/env bash
export CYBER_PATH="$(readlink -fn "$(dirname "${BASH_SOURCE[0]}")")"

export PATH="${CYBER_PATH}/bin:${PATH}"
export PYTHONPATH="${CYBER_PATH}/python:/opt/local/lib/python2.7/site-packages:${PYTHONPATH}"

export CYBER_DOMAIN_ID=80
export CYBER_IP=127.0.0.1

export GLOG_log_dir="${CYBER_PATH}/log"
export GLOG_alsologtostderr=0
export GLOG_colorlogtostderr=1
export GLOG_minloglevel=0

export sysmo_start=0

# for DEBUG log
#export GLOG_v=4
